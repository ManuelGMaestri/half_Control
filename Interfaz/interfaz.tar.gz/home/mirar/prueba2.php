 <!DOCTYPE html>
<html>
<body>

<h1>My First Web Page</h1>
<p>My First Paragraph</p>

<form>
<input type="" id="sensor1">
<input type="" id="sensor2">
<input type="" id="sensor3">
<input type="" id="sensor4">
<input type="" id="sensor5">
<input type="" id="sensor6">
</form>
<script>
document.getElementById("sensor1").value = Math.floor(Math.random() *1023) + 0; //simulacion de arduino  //
document.getElementById("sensor2").value = Math.floor(Math.random() *1023) + 0; //simulacion de arduino  //
document.getElementById("sensor3").value = Math.floor(Math.random() *1023) + 0; //simulacion de arduino  // Serian los sensores, que
document.getElementById("sensor4").value = Math.floor(Math.random() *1023) + 0; //simulacion de arduino  // que estan conectados.
document.getElementById("sensor5").value = Math.floor(Math.random() *1023) + 0; //simulacion de arduino  //
document.getElementById("sensor6").value = Math.floor(Math.random() *1023) + 0; //simulacion de arduino  //

</script>

</body>
</html> 