<!-- By http://jquery-manual.blogspot.com -->
<!DOCTYPE HTML>
<html>
<head>
<script type="text/javascript">
function convertir_a_dollares(euro)
{
numero = /[0-9\.]$/

if (!numero.exec(euro))
{
alert("Esto no es un número");
}
else
{
dollar = parseFloat(1.3086);
resultado = dollar*parseFloat(euro);
document.getElementById("total").innerHTML = euro + " euros son... " + resultado.toFixed(2) + " dollares";
}
}
//---
function convertir_a_euros(dollar)
{
numero = /[0-9\.]$/

if (!numero.exec(dollar))
{
alert("Esto no es un número");
}
{
euro = parseFloat(0.7641);
resultado = euro*parseFloat(dollar);
document.getElementById("total").innerHTML = dollar + " dollares son ... " + resultado.toFixed(2) + " euros";
}
}
</script>
</head>
<body>
<input type="text" id="dollar"><input type="button" value="Convertir de Euro a dollar" onclick="convertir_a_dollares(document.getElementById('dollar').value)">
<br>
<input type="text" id="euros"><input type="button" value="Convertir de dollar a Euro" onclick="convertir_a_euros(document.getElementById('euros').value)">
<br>
<div id="total">
</div>
</body>
</html>