<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HalfControl - Mirar</title>
  <link href="../../css_visuals/GSSheet.css" rel="stylesheet" type="text/css">
  <link href="../../css_visuals/W3Sheet.css" rel="stylesheet" type="text/css">
  <link href="../../css_visuals/demo.css" rel="stylesheet" type="text/css">
  <link href="../../css_visuals/footer.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat|Ubuntu+Condensed" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
</head>
<body ondragstart="return false" onselectstart="return false" oncontextmenu="return false">
 <a href="../home.php"><div class="heading"> Half<p class="headingLog">Control</p></div></a>
  <div class="w3-row-padding w3-padding-64 w3-container">
  <div class="w3-content">
    <div class="w3-twothird">
      <h1>Mirar </h1>
      <h5 class="w3-padding-32">Este es el menu donde vas a poder los valores de tus sensores, convertirlos y hasta verlos en graficos.
      </h5> 
    </div>
    <div class="w3-third w3-center homeIconSize">
      <i class="fa fa-search anchorSize w3-padding-64 w3-text-red"  style="font-size: 200px;"></i>
    </div>
  </div>
</div>

 <div class="w3-container">
 <h2>Tabla de valores de los sensores</h2>
  <h5>Los sensores estan ordenados en el mismo orden en el que aparecen en el <b>HalfControl</b>, para saber cual es cual, solo tienes que mirar el numero de sensor al que conectaste cada uno. Por ahora, solo hacemos conversiones de 4 sensores, <b>temperatura, humedad relativa, proximidad y luminosidad.</b></h5>
 </div>
<div class="w3-responsive">
<table class="w3-table-all w3-hoverable">
<tr class="w3-green">
  <th>Sensor</th>
  <th style="text-align: center;">Temperatura</th>
  <th style="text-align: center;">Humedad</th>
  <th style="text-align: center;">Luminosidad</th>
  <th style="text-align: center;">Proximidad</th>
</tr>
<tr>
  <td>S1</td>
  <td style="text-align: center;"> <input type="" name="temp" class="temp" value="1000" id="temp" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="hume" class="hume" id="hume" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="lumi" class="lumi" id="lumi" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="prox" class="prox" id="prox" size="10" readonly></td>
</tr>
<tr>
  <td>S2</td>
  <td style="text-align: center;"> <input type="" name="temp" class="temp" id="temp" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="hume" class="hume" id="hume" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="lumi" class="lumi" id="lumi" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="prox" class="prox" id="prox" size="10" readonly></td>
</tr>
<tr>
  <td>S3</td>
  <td style="text-align: center;"> <input type="" name="temp" class="temp" id="temp" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="hume" class="hume" id="hume" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="lumi" class="lumi" id="lumi" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="prox" class="prox" id="prox" size="10" readonly></td>
</tr>
<tr>
  <td>S4</td>
  <td style="text-align: center;"> <input type="" name="temp" class="temp" id="temp" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="hume" class="hume" id="hume" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="lumi" class="lumi" id="lumi" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="prox" class="prox" id="prox" size="10" readonly></td>
</tr>
<tr>
  <td>S5</td>
  <td style="text-align: center;"> <input type="" name="temp" class="temp" id="temp" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="hume" class="hume" id="hume" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="lumi" class="lumi" id="lumi" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="prox" class="prox" id="prox" size="10" readonly></td>
</tr>
<tr>
  <td>S6</td>
  <td style="text-align: center;"> <input type="" name="temp" class="temp" id="temp" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="hume" class="hume" id="hume" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="lumi" class="lumi" id="lumi" size="10" readonly></td>
  <td style="text-align: center;"> <input type="" name="prox" class="prox" id="prox" size="10" readonly></td>
</tr>
</table>
</div>
<!--Estado de los actuadores-->
<br>
<br>

 <div class="w3-container">
 <h2>Estado de los actuadores</h2>
  <h5>Los actuadores estan ordenados en el mismo orden en el que aparecen en el <b>HalfControl</b>, para saber cual es cual, solo tienes que mirar el numero de actuador al que conectaste cada uno. Hay dos estados, <b>ON</b> y <b>OFF</b></h5>
 </div>
<div class="w3-responsive">
<table class="w3-table-all w3-hoverable">
<tr class="w3-green">
  <th>Sensor</th>
  <th style="text-align: center;">ON</th>
  <th style="text-align: center;">OFF</th>
</tr>
<tr>
  <td>A1</td>
  <td></td>
  <td></td>
</tr>
<tr>
  <td>A2</td>
  <td></td>
  <td></td>
</tr>
<tr>
  <td>A3</td>
  <td></td>
  <td></td>
</tr>
<tr>
  <td>A4</td>
  <td></td>
  <td></td>
</tr>
<tr>
  <td>A5</td>
  <td></td>
  <td></td>
</tr>
<tr>
  <td>A6</td>
  <td></td>
  <td></td>
</tr>
</table>
</div>
<!--footer-->
 <footer class="footer-distributed">
      <div class="footer-left">
        <h3>Half<span class="">Control</span></h3>
        <p class="footer-links">
          <a href="#">Home</a>
          ·
          <a href="#">Sobre nosotros</a>
          ·
          <a href="#">Contacto</a>
        </p>
        <p class="footer-company-name">HalfServices &copy; 2016 - 2017</p>
      </div>
      <div class="footer-center">
       <div>
          <i class="fa fa-map-marker"></i>
          <p><span></span> Tandil, Argentina</p>
        </div>
        <div>
          <i class="fa fa-phone"></i>
          <p>+54 2494660399</p>
        </div>
        <div>
          <i class="fa fa-envelope"></i>
          <p><a href="mailto:half.web.services@gmail.com">Half.Services@gmail.com</a></p>
        </div>
      </div>
      <div class="footer-right">
        <p class="footer-company-about">
          <span>Sobre la empresa</span>
          Impulsados por los nuevos avances en la informatica, dia a dia innovamos con
          nuevos proyectos y desarrollos orientados a mejorar la calidad de vida.
        </p>
        <div class="footer-icons">
          <a href="#"><i class="fa fa-facebook"></i></a>
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-linkedin"></i></a>
          <a href="#"><i class="fa fa-github"></i></a>
        </div>
      </div>
    </footer>
    <script src="js/conver_valores.js"></script>
   </body>
</html>