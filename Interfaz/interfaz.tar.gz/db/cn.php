<?php
$link = mysqli_connect("localhost", "root", "??1238", "controlHalf");	
//if (!$link) {
//  	echo 'nop';
//  } 
//  else {
//  	echo 'si';
//  }