<?php 
include ("cn.php");
 ?>